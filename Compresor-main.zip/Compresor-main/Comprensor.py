import numpy as np
import time

def compress_string(s):
    freq_dict = {}
    print("diccionario")
    for c in s:
        freq_dict[c] = freq_dict.get(c, 0) + 1

    print("tuplas")
    # crea una lista de tuplas (carácter, frecuencia)
    freq_list = [(c, f) for c, f in freq_dict.items()]

    print("ordenar")
    # ordena la lista por frecuencia ascendente
    freq_list = sorted(freq_list, key=lambda x: x[1])

    print("tabla de simbolos")
    # crea una tabla de símbolos (un diccionario que asigna a cada carácter un código binario único)
    symbol_table = {}
    code = '0'
    for c, f in freq_list:
        symbol_table[c] = code
        code = bin(int(code, 2) + 1)[2:]

    print("Comprimir")
    # comprime la cadena
    compressed = ''.join([symbol_table[c] for c in s])

    print("matriz")
    # convierte la cadena comprimida en una matriz de enteros de 8 bits y la almacena en un archivo
    compressed_bytes = np.packbits(np.array([int(b) for b in compressed], dtype=np.uint8))
    with open('./comprimido.elmejorprofesor', 'wb') as f:
        f.write(compressed_bytes)

    return compressed_bytes

def decompress_string(compressed_bytes):
    # desempaqueta la matriz de enteros de 8 bits y la convierte en una cadena de bits
    compressed_bits = ''.join([np.binary_repr(b, width=8) for b in np.unpackbits(compressed_bytes)])

    # crea una tabla inversa de símbolos (un diccionario que asigna a cada código binario un carácter)
    symbol_table_inv = {v: k for k, v in symbol_table_inv.items()}

    # descomprime la cadena
    uncompressed = ''
    code = ''
    for bit in compressed_bits:
        code += bit
        if code in symbol_table_inv:
            uncompressed += symbol_table_inv[code]
            code = ''

    # almacena la cadena descomprimida en un archivo
    with open('./archivo_descomprimido.txt', 'w') as f:
        f.write(uncompressed)

    return uncompressed


inicio = time.time()
# Nombre del archivo de texto a comprimir
filename = './LaBiblia.txt'

# Abrir el archivo de texto y leer su contenido
with open(filename, 'r', encoding='latin-1') as f:
    text = f.read()

texto = compress_string(text)

fin = time.time()
print(fin - inicio)
