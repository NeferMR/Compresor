import time

TiempoInicio=time.time()

def base64_to_bin(b64num):
  Dicc="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  decimal_nums=[Dicc.index(char) for char in b64num]
  binCh=[format(num, "06b") for num in decimal_nums]
  binStr="".join(binCh)  
  pos=0
  for i in range(8):
    if binStr[0] =="0":
      binStr = binStr[1:]     
    else:
      break
  return binStr
hexaD= []
ArCom= open("./comprimido.elmejorprofesor", "r", encoding="latin-1").read()
divider= ArCom.split("@")
lbin2= {}


i=0

while i < len(divider)-2 :
  lbin2[divider[i+1]]=divider[i]
  i=i+2
wr=divider[len(divider)-2] + base64_to_bin(divider[len(divider)-1])
uncomStr = ""
cod= ""
for dig in wr:
  cod= cod+dig
  if cod in lbin2:    
    uncomStr= uncomStr+lbin2[cod]
    cod= ""        
descom=open("./descomprimido-elmejorprofesor.txt", "w", encoding="latin-1")
descom.write(uncomStr)
descom.close()
print("Descomprimido")

TiempoFinal=time.time()

ExecTime=TiempoFinal-TiempoInicio

TiempoTotal=round(ExecTime, 2)

print("El tiempo de ejecución fue:",TiempoTotal,"segundos")