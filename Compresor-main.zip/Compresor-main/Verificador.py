
Bible = []
for line in open("./Archivos/LaBiblia.txt", 'r', encoding="latin-1").readlines():
  Bible.append(line)
Descomprimido = []
for line in open("./Archivos/descomprimido-elmejorprofesor.txt", 'r', encoding="latin-1").readlines():
  Descomprimido.append(line)
if(Bible == Descomprimido):
  print("Ok")
else:
  print("Nok")